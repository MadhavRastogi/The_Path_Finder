package com.example.findloc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Savloc extends AppCompatActivity {
    String[] values = new String[] {
            "Indira Nagar",
            "Daliganj",
            "Vikas Khand",
            "Park Road",
            "Church Road",
            "Aliganj",
            "Virat Khand",
            "Hazratganj",
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_savloc);
        ListView listView=(ListView) findViewById(R.id.ListView);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,values);
        listView.setAdapter(adapter);
    }
}
